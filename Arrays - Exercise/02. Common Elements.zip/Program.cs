﻿using System;
using System.Linq;

namespace _02._Common_Elements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] arr1 = Console.ReadLine().Split();
            string[] arr2 = Console.ReadLine().Split();
            string obshti = "";
            for (int i = 0; i < arr2.Length; i++)
            {
                for (int j  = 0; j  < arr1.Length; j ++)
                {
                    if (arr2[i] == arr1[j])
                    {
                        obshti += $"{arr2[i]} ";
                    }
                }
            }
            Console.WriteLine(obshti);
            
        }
    }
}
