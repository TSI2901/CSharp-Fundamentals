﻿using System;

namespace _01._Train
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] numbers = new int[n];
            int sum = 0;
            for (int i = 0; i < n; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
                Console.Write($"{numbers[i]} ");
                
                sum += numbers[i];
            }
            Console.WriteLine("");
            Console.WriteLine(sum);
        }
    }
}
