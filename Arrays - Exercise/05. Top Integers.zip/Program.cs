﻿using System;
using System.Linq;

namespace _05._Top_Integers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arr = Console.ReadLine().Split().Select(int.Parse).ToArray();
            
            int[] empty = new int[arr.Length];
            bool flag = false;
            int broqch = 0;
            for (int i = 0; i < arr.Length - 1; i++)
            {
                for (int j = 0; j < arr.Length; j++)
                {
                    if (arr[i] > arr[i + 1])
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    } 
                }
                if (flag) 
                {
                    Console.Write($"{arr[i]} ");
                    
                }
            }
            Console.Write(arr[arr.Length - 1]);

        }
    }
}
//broqch++;
//empty[broqch] += arr[i];