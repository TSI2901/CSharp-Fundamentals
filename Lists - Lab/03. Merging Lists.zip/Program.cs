﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _03._Merging_Lists
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> pyrvi = Console.ReadLine().Split().Select(int.Parse).ToList();
            List<int> vtori = Console.ReadLine().Split().Select(int.Parse).ToList();
            if (pyrvi.Count >= vtori.Count)
            {
                for (int i = 0; i < pyrvi.Count ; i++)
                {
                    if (i == vtori.Count || i > vtori.Count)
                    {
                        Console.Write($"{pyrvi[i]} ");
                    }
                    else
                    {
                        Console.Write($"{pyrvi[i]} {vtori[i]} ");
                    }
                }
            }
            else if (vtori.Count >= pyrvi.Count)
            {
                for (int i = 0; i < vtori.Count; i++)
                {
                    if (i == pyrvi.Count || i > pyrvi.Count)
                    {
                        Console.Write($"{vtori[i]} ");
                    }
                    else
                    {
                        Console.Write($"{pyrvi[i]} {vtori[i]} ");
                    }
                }
            }
            
        }
    }
}
