﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _01._Sum_Adjacent_Equal_Numbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<double> names = Console.ReadLine().Split().Select(double.Parse).ToList();
            for (int i = 0; i < names.Count - 1; i++)
            {
                if (names[i] == names[i + 1])
                {
                    names[i] += names[i + 1];
                    names.RemoveAt(i + 1);
                    i = -1;
                }
            }
            Console.WriteLine(String.Join(" ", names));
        }
    }
}
