﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _06._List_Manipulation_Basics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = Console.ReadLine().Split().Select(int.Parse).ToList();
            while (true)
            {
                string line = Console.ReadLine();
                if (line == "end")
                {
                    break;
                }
                string[] split = line.Split();
                switch (split[0])
                {
                    case "Add":
                        int nubertoadd = int.Parse(split[1]);
                        numbers.Add(nubertoadd);
                        break;
                    case "Remove":
                        int nubertoremove = int.Parse(split[1]);
                        numbers.Remove(nubertoremove);
                        break;
                    case "RemoveAt":
                        int index = int.Parse(split[1]);
                        numbers.RemoveAt(index);
                        break;
                    case "Insert":
                        int nubertoinsirt = int.Parse(split[1]);
                        int indextoinsert = int.Parse(split[2]);
                        numbers.Insert(indextoinsert, nubertoinsirt);
                        break;
                }
            }
            Console.WriteLine(String.Join(" ", numbers));
        }
    }
}
