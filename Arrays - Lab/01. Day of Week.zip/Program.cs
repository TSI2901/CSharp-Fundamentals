﻿using System;

namespace _01._Day_of_Week
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] DayOfWeek = new string[8];
            DayOfWeek[0] = "fhjl";
            DayOfWeek[1] = "Monday";
            DayOfWeek[2] = "Tuesday";
            DayOfWeek[3] = "Wednesday";
            DayOfWeek[4] = "Thursday";
            DayOfWeek[5] = "Friday";
            DayOfWeek[6] = "Saturday";
            DayOfWeek[7] = "Sunday";
            if (n > 7 || n <= 0)
            {
                Console.WriteLine("Invalid day!");
            }
            else
            {
                Console.WriteLine(DayOfWeek[n]);
            }
            
        }
    }
}
